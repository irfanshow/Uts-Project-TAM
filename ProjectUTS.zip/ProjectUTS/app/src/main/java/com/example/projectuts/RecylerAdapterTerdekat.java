package com.example.projectuts;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecylerAdapterTerdekat extends RecyclerView.Adapter<RecylerAdapterTerdekat.MyViewHolder> {

    private String[] list;


    public RecylerAdapterTerdekat(String[]list){
        this.list=list;


    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RecylerAdapterTerdekat.MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_terdekat,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.textView.setText(list[position]);
    }


    @Override
    public int getItemCount() {
        return list.length;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView textView;
        ImageView imageView;
        Button buttonChat;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.nameTerdekat);
            buttonChat = itemView.findViewById(R.id.btn_chat);
            imageView = itemView.findViewById(R.id.img_terdekat);
        }
    }
}
