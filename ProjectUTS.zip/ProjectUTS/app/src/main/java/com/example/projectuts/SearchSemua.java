package com.example.projectuts;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class SearchSemua extends Fragment {

    private String[] namaSemua = {"Katrina","Hu Tao","Yoimiya","Jean","Klee","Paradox","Nichijou","Doscord"};
    private String[] AsalSemua = {"Indonesia","China","Jepang","USA","USA","Rusia","Jepang","Netherland"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search_semua2, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recylerSemua);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setAdapter(new RecylerAdapterSemua(namaSemua,AsalSemua));

        return view;
    }
}