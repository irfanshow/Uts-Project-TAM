package com.example.projectuts;

import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;



public class SearchNegara extends Fragment {

    private String[] namaNegara = {"Indonesia","Arabia","India","Jepang","Korea","Rusia","Swizz"
            ,"Netherland","Singapore","Vietnam"

    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        
        View view = inflater.inflate(R.layout.fragment_search_negara2, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recylerNegara);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setAdapter(new RecylerAdapter(namaNegara));

        return view;
         }



    }

