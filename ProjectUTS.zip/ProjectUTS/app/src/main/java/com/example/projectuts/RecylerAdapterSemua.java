package com.example.projectuts;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecylerAdapterSemua extends RecyclerView.Adapter<RecylerAdapterSemua.MyViewHolder> {

    private String[] list;
    private String[] listAsal;


    public RecylerAdapterSemua(String[]list,String[]listAsal){
        this.list=list;
        this.listAsal=listAsal;


    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RecylerAdapterSemua.MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_semua,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.textView.setText(list[position]);
        holder.descView.setText("Dari "+listAsal[position]);
    }


    @Override
    public int getItemCount() {
        return list.length;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView textView;
        TextView descView;
        ImageView imageView;
        Button buttonChat;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.nameSemua);
            descView = itemView.findViewById(R.id.desc_info_semua);
            buttonChat = itemView.findViewById(R.id.btn_chat_semua);
            imageView = itemView.findViewById(R.id.img_semua);
        }
    }
}