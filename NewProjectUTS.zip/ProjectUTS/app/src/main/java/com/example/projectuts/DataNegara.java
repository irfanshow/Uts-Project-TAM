package com.example.projectuts;

public class DataNegara {


    public static String[] namaNegara = new String[] {"Indonesia","Saudi Arabia","India","Jepang","South Korea","Rusia","United Kingdom"
            ,"Netherland","Singapore","Vietnam","Unites States"};

    public static int[] benderaNegara = new int[]
            {
              R.drawable.indonesia, R.drawable.arabia,R.drawable.india,
                    R.drawable.japan,R.drawable.south_korea,R.drawable.rusia,
                    R.drawable.unitedkingdom, R.drawable.neherlandl,R.drawable.singapore,
                    R.drawable.vietnam,R.drawable.us
            };
}
