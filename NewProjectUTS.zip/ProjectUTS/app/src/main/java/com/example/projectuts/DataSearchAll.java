package com.example.projectuts;

public class DataSearchAll {
    public static String[] namaSearchAll = new String[] {"Sahna","Feyna","Miyuki",
            "James","Tom","Katherine"};

    public static int[] ProfileSearchAll = new int[]
            {
                    R.drawable.profile10, R.drawable.profile8,R.drawable.profile1,
                    R.drawable.profile4,R.drawable.profile5,R.drawable.profile6
            };

    public static String[] AsalSemua = new String[] {"Indonesia","Rusia","Jepang",
            "United States","United States","United Kingdom"};


}
