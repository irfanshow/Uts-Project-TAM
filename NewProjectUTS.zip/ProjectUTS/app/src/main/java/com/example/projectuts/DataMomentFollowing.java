package com.example.projectuts;

public class DataMomentFollowing {

    public static String[] namaMomentFollowing = new String[] {"Bon"};

    public static int[] ProfileMomentFollowing = new int[]
            {
                    R.drawable.profile5
            };

    public static String[] statusMomentFollowing = new String[] {"Koq suzah sich"};

}
