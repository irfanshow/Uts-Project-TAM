package com.example.projectuts;

public class DataMomentAll {


    public static String[] namaMomentAll = new String[] {"Lola","Kima","Yaw"};

    public static int[] ProfileMomentAll = new int[]
            {
                    R.drawable.profile10, R.drawable.profile8,R.drawable.profile1
            };

    public static String[] statusMomentAll = new String[] {"Imma bout to go xrazy","Busy rn","Working in boring"};
}
