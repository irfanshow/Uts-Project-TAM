package com.example.projectuts;

public class DataChatAll {



    public static String[] namaChatAll = new String[] {"Ellain","Yah0","G4UL"};

    public static int[] ProfileChatAll = new int[]
            {
                    R.drawable.profile10, R.drawable.profile8,R.drawable.profile1
            };

    public static String[] pesanChatAll = new String[] {"Online","Offline","Offline"};

}
