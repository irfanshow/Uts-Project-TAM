package com.example.projectuts;

public class DataChatTerkini {
    public static String[] namaChatTerkini = new String[] {"Ellain"};

    public static int[] ProfileChatTerkini= new int[]
            {
                    R.drawable.profile10,R.drawable.profile9
            };

    public static String[] pesanChatTerkini = new String[] {"Online"};
}
