package com.example.projectuts;

public class DataAbout {
    public static String[] namaAbout = new String[] {"Irfan Saputra","Ananto Akbar","Ahmad Muzakki","Saddam Surya"};

    public static int[] ProfileAbout = new int[]
            {
                    R.drawable.profile, R.drawable.profile,R.drawable.profile,R.drawable.profile
            };

    public static String[] NPM = new String[] {"2017051035","2017051069","2017051037","2017051014"};

}
