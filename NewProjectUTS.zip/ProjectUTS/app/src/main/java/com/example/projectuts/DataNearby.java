package com.example.projectuts;

public class DataNearby {

    public static String[] namaNeaby = new String[] {"Khofifah","Zahra","Elly"};

    public static int[] ProfileNearby = new int[]
            {
                    R.drawable.profile3, R.drawable.profile9,R.drawable.profile10,

            };
}
